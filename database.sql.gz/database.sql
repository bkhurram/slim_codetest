# ************************************************************
# Sequel Ace SQL dump
# Versione 20078
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# Host: localhost (MySQL 8.0.32)
# Database: qwentes
# Tempo Di Generazione: 2024-12-09 23:17:44 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump della tabella post_tag
# ------------------------------------------------------------

DROP TABLE IF EXISTS `post_tag`;

CREATE TABLE `post_tag` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int unsigned NOT NULL,
  `tag_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_post_tag_ids` (`post_id`,`tag_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `post_tag_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_tag_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `post_tag` WRITE;
/*!40000 ALTER TABLE `post_tag` DISABLE KEYS */;

INSERT INTO `post_tag` (`id`, `post_id`, `tag_id`)
VALUES
	(22,17,5),
	(23,17,6),
	(24,17,7),
	(25,18,5),
	(26,18,6),
	(27,18,7),
	(30,19,5),
	(31,19,6),
	(32,19,7);

/*!40000 ALTER TABLE `post_tag` ENABLE KEYS */;
UNLOCK TABLES;


# Dump della tabella posts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `posts`;

CREATE TABLE `posts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;

INSERT INTO `posts` (`id`, `uuid`, `title`, `body`, `status`)
VALUES
	(17,'47f9a9ad-6dd3-42fc-a7f0-9cb6061d53df','Khurram Bashir','This is the content of an amazing post sviluppatore','online'),
	(18,'e19be0b6-1263-4ac1-930e-df34d2277b7b','Khurram Bashir','This is the content of an amazing post sviluppatore','online'),
	(19,'e19be0b6-1263-4ac1-930e-df34d2277b7b','Khurram Bashir','This is the content of an amazing post sviluppatore','online');

/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump della tabella tags
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tags`;

CREATE TABLE `tags` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;

INSERT INTO `tags` (`id`, `slug`, `name`)
VALUES
	(4,'nodejs','nodejs'),
	(5,'php','PHP'),
	(6,'laravel','Laravel'),
	(7,'slim','Slim');

/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;


# Dump della tabella user_addresses
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_addresses`;

CREATE TABLE `user_addresses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `postCode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `countryCode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `lat` decimal(10,8) DEFAULT NULL,
  `lng` decimal(10,8) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`userId`),
  CONSTRAINT `user_addresses_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `user_addresses` WRITE;
/*!40000 ALTER TABLE `user_addresses` DISABLE KEYS */;

INSERT INTO `user_addresses` (`id`, `userId`, `street`, `city`, `postCode`, `countryCode`, `lat`, `lng`)
VALUES
	(2,17,'Via mentana 33','Magenta','20013','IT',40.71282323,-74.00623232),
	(3,18,'Via mentana 33','Magenta','20013','IT',40.71282323,-74.00623232),
	(4,19,'Via mentana 33','Magenta','20013','IT',40.71282323,-74.00623232),
	(6,21,'Via mentana 33','Magenta','20013','IT',40.71282323,-74.00623232),
	(9,24,'Via Milano 1','Magenta','20013','IT',40.12345679,-74.12345679),
	(10,25,'Via mentana 33','Magenta','20013','IT',40.71282323,-74.00623232);

/*!40000 ALTER TABLE `user_addresses` ENABLE KEYS */;
UNLOCK TABLES;


# Dump della tabella users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `givenName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `familyName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dateOfBirth` date DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `givenName`, `familyName`, `email`, `password`, `dateOfBirth`, `createdAt`)
VALUES
	(2,'Mario',NULL,'mario@msn.com','$2y$10$1lRldK8NfJfCtpehE2X2RuiMEZpN/8FcnHOTZn/2mSKjAYupf8s8e',NULL,NULL),
	(3,'luigi','rossi','luigi@gmail.com','$2y$10$1lRldK8NfJfCtpehE2X2RuiMEZpN/8FcnHOTZn/2mSKjAYupf8s8e',NULL,NULL),
	(4,'test','test','test2@gmail.com','123',NULL,'2024-12-08 22:30:41'),
	(5,'mario','rossi','luigi1@gmail.com','$2y$10$wAPYKR2s3fweb5j5gvH7muxnP0GlCfUD5e4z7qtDwkIt..JKyti1G','1990-09-11','2024-12-09 02:02:21'),
	(6,'mario','rossi','luigi12@gmail.com','$2y$10$RYV9kYmD5YPkY8lFkpTstOX3qcPOAfLulgtavVhUtYwamHhe75sb6',NULL,'2024-12-09 08:52:29'),
	(17,'mario','rossi','luigi132@gmail.com','$2y$10$YhINPJD.bNA9zC0ZKzMcqOjDGBlfIDpjmcEkmhIRXBQ.02JNDGfYS',NULL,'2024-12-09 11:15:16'),
	(18,'mario','rossi','luigi1312@gmail.com','$2y$10$bDep2jWqlnAJoHj/PBdUauPwz7flWBqa27NVy.iAaWXwj675d3Bbq',NULL,'2024-12-09 11:23:16'),
	(19,'mario','rossi','luigi1312x@gmail.com','$2y$10$TqMkjhZTFmjXNWgBliYYPeZ22RJYYUVBddvWeGxC46ySnJQ5zfD/K','1990-09-11','2024-12-09 11:25:56'),
	(21,'Khurram','Bashir','kbc@gmail.com','$2y$10$WvilPxwXBmJzaI3LYfiexOpUVVb83ebdlmlg1x/NIYb61KFdl4PGi','1990-09-11','2024-12-09 12:40:48'),
	(24,'Khurram','Bashir','kbxxx@gmail.com','$2y$10$ed618bo8FeiD0/Se8YA7m.TxhNTYCe.UKst6dNVDb8x/4CJsYzIRa','1990-09-19','2024-12-09 13:07:53'),
	(25,'Khurram','Bashir','kb@gmail.com','$2y$10$2iGqsKy6kChHAYHSkZLx0.8/gW198VM7apKXj70wGA7Ri/pV0Z.TO','1990-09-11','2024-12-09 13:14:21'),
	(26,'mario','rossi','mario.rossi@msn.com','$2y$10$0yYzUwicoYfd3JmqnS4gGOx3e7aBmRABLOdwWjnipfvh3P0f3Mssq',NULL,'2024-12-09 18:29:18'),
	(27,'root','root','my.root@gmail.com','$2y$10$vHH5gIWeTOn1nrdRYB27ie0.Ky9I885wDqlOwfB.Bpip9JIRACcpK',NULL,'2024-12-09 18:32:52');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
